import 'dart:math';

Random random = Random();

int generateRandomNumber() {
  return random.nextInt(10000000);
}